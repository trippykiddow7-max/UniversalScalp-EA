package com.universalscalpea.companion;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
  EditText risk,maxloss,bridge; TextView status; SharedPreferences prefs;
  @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
    risk=findViewById(R.id.risk); maxloss=findViewById(R.id.maxloss); bridge=findViewById(R.id.bridge); status=findViewById(R.id.status);
    prefs=getSharedPreferences("ea",0); risk.setText(prefs.getString("risk","0.5")); maxloss.setText(prefs.getString("maxloss","5")); bridge.setText(prefs.getString("bridge",""));
    findViewById(R.id.connect).setOnClickListener(v->{prefs.edit().putString("risk",risk.getText().toString()).putString("maxloss",maxloss.getText().toString()).putString("bridge",bridge.getText().toString()).apply(); status.setText("● SETTINGS SAVED — BRIDGE READY"); status.setTextColor(Color.rgb(76,175,80)); Toast.makeText(this,"Settings saved",Toast.LENGTH_SHORT).show();});
    findViewById(R.id.closeall).setOnClickListener(v->Toast.makeText(this,"Emergency command requires an authorized MT5 bridge.",Toast.LENGTH_LONG).show());
  }
}
