# Build the APK from an Android phone

1. Create/sign in to a GitHub account.
2. Create a new repository (for example: UniversalScalpEA).
3. Upload all files/folders from this project ZIP, preserving the `.github/workflows/build-apk.yml` path.
4. Open the repository's **Actions** tab.
5. Select **Build Universal Scalp EA APK** and tap **Run workflow**.
6. Wait for the green checkmark.
7. Open the completed workflow run and download the artifact named **UniversalScalpEA-debug-apk**.
8. Extract the artifact and install `app-debug.apk` on Android. Android may ask you to allow installation from the browser/file manager.

Important: this APK is a dashboard/controller shell. It does not execute an MT5 `.ex5` inside Android. Trading commands require an authorized MT5 bridge and an EA running in MT5.
